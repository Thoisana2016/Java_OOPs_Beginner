package dev.thoisana.ProductServiceAPI21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductServiceApi21Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductServiceApi21Application.class, args);
	}

}
