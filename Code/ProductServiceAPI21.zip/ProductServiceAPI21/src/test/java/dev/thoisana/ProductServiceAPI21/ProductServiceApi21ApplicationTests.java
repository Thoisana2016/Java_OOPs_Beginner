package dev.thoisana.ProductServiceAPI21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceApi21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
